package com.lagou.oss;

import com.aliyun.oss.OSS;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSClientBuilder;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class FileUpload {
    public static void main(String[] args) throws  Exception{
        String  endpoint = "oss-cn-beijing.aliyuncs.com";
        String  accessKeyId = "LTAI4GD1XcQgrQuvkKnZYhhA";
        String  accessKeySecret = "1n2i3VNxd5gWr9YPYuJbVMophsXUQr";
        // 创建OSSClient 实例
        OSS  ossClient = new OSSClientBuilder().build(endpoint,accessKeyId,accessKeySecret);
        // 获取上传文件流
        InputStream  inputStream  = new FileInputStream(new File("src/main/resources/1.png"));
        ossClient.putObject("lagou-imgs","拉勾教育.png",inputStream);
        ossClient.shutdown();
    }
}
