package com.lagou;

import org.csource.common.MyException;
import org.csource.common.NameValuePair;
import org.csource.fastdfs.*;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FastDFSTest {
    /** 文件上传测试 */
    @Test
    public  void  testUpload(){
        try {
            // 加载配置文件
            ClientGlobal.initByProperties("fastdfs-client.properties");
            // 创建tracker客户端
            TrackerClient trackerClient = new TrackerClient();
            // 根据tracker客户端端获取连接  获取跟踪服务器对象
            TrackerServer trackerServer = trackerClient.getConnection();
            StorageServer storageServer = null;
            // 定义存储客户端
            StorageClient1 client1 = new StorageClient1(trackerServer,storageServer);
            //文件元信息
            NameValuePair[] list = new NameValuePair[1];
            list[0] = new NameValuePair("fileName", "1.png");
            // 上传文件
            String fileId = client1.upload_file1("1.png","jpg",list);
            System.out.println(fileId);
            // group1/M00/00/00/wKjTiF7iGy6AMefcAACGZa9JdFo097.png
            // group1/M00/00/00/wKjTiF7iG1qAV_H_AACGZa9JdFo705.jpg
            // group1/M00/00/00/wKjTiF7iG7iAHOlDAACGZa9JdFo210.jpg
        } catch (IOException e) {
            e.printStackTrace();
        } catch (MyException e) {
            e.printStackTrace();
        }
    }
    @Test
    public  void  testQuery(){
        try {
            // 加载配置文件
            ClientGlobal.initByProperties("fastdfs-client.properties");
            // 创建tracker客户端
            TrackerClient trackerClient = new TrackerClient();
            // 根据tracker客户端端获取连接  获取跟踪服务器对象
            TrackerServer trackerServer = trackerClient.getConnection();
            StorageServer storageServer = null;
            // 定义存储客户端
            StorageClient1 client1 = new StorageClient1(trackerServer,storageServer);

            FileInfo fileInfo = client1.query_file_info1("group1/M00/00/00/wKjTiF7iG7iAHOlDAACGZa9JdFo210.jpg");
            NameValuePair[] nameValuePairs = client1.get_metadata1("group1/M00/00/00/wKjTiF7iG7iAHOlDAACGZa9JdFo210.jpg");
            System.out.println(nameValuePairs);
            if(nameValuePairs != null){
                for (int i=0;i<nameValuePairs.length;i++){
                    System.out.println(nameValuePairs[i].getName() + ":"+nameValuePairs[i].getValue());
                }
            }
            System.out.println(fileInfo);
            // group1/M00/00/00/wKjTiF7iGy6AMefcAACGZa9JdFo097.png
            // group1/M00/00/00/wKjTiF7iG1qAV_H_AACGZa9JdFo705.jpg
            // group1/M00/00/00/wKjTiF7iG7iAHOlDAACGZa9JdFo210.jpg
        } catch (IOException e) {
            e.printStackTrace();
        } catch (MyException e) {
            e.printStackTrace();
        }
    }
    @Test
    public  void  testDownload(){
        try {
            // 加载配置文件
            ClientGlobal.initByProperties("fastdfs-client.properties");
            // 创建tracker客户端
            TrackerClient trackerClient = new TrackerClient();
            // 根据tracker客户端端获取连接  获取跟踪服务器对象
            TrackerServer trackerServer = trackerClient.getConnection();
            StorageServer storageServer = null;
            // 定义存储客户端
            StorageClient1 client1 = new StorageClient1(trackerServer,storageServer);
            byte[] bs = client1.download_file1("group1/M00/00/00/wKjTiF7iGy6AMefcAACGZa9JdFo097.png");
            FileOutputStream fileOutputStream = new FileOutputStream(new File("download.png"));
            fileOutputStream.write(bs);
            fileOutputStream.close();
            // group1/M00/00/00/wKjTiF7iGy6AMefcAACGZa9JdFo097.png
            // group1/M00/00/00/wKjTiF7iG1qAV_H_AACGZa9JdFo705.jpg
            // group1/M00/00/00/wKjTiF7iG7iAHOlDAACGZa9JdFo210.jpg
        } catch (IOException e) {
            e.printStackTrace();
        } catch (MyException e) {
            e.printStackTrace();
        }
    }
}
