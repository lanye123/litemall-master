package com.lagou.test;

import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import org.bson.Document;

public class DocumentFindFiltersTest {
    public static void main(String[] args) {
        MongoClient  mongoClient  = new MongoClient("192.168.211.133",37017);
        // 获取数据库对象
        MongoDatabase  mongoDatabase  = mongoClient.getDatabase("lg_resume");
        // 获取集合对象
        MongoCollection<Document>  collection = mongoDatabase.getCollection("lg_resume_preview");
        // 要根据expectSalary 降序排列
        Document  sortDocument  =  new Document();
        sortDocument.append("expectSalary",-1);
        //FindIterable<Document>  findIterable =  collection.find(Document.parse("{expectSalary:{$gt:21000}}")).sort(sortDocument);
        FindIterable<Document>  findIterable =  collection.find(Filters.gt("expectSalary",21000)).sort(sortDocument);
        for(Document document : findIterable){
            System.out.println(document);
        }
        mongoClient.close();
    }
}
