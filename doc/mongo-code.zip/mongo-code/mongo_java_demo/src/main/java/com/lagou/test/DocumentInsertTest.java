package com.lagou.test;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class DocumentInsertTest {
    public static void main(String[] args) {
        MongoClient  mongoClient  = new MongoClient("192.168.211.133",37017);
        // 获取数据库对象
        MongoDatabase  mongoDatabase  = mongoClient.getDatabase("lg_resume");
        // 获取集合对象
        MongoCollection<Document>  collection = mongoDatabase.getCollection("lg_resume_preview");
        //  构建Document 对象  并插入到集合中
        Document  document  = Document.parse("{name:'lisi',city:'北京',birth_day:new ISODate('2001-08-01'),expectSalary:18000}");
        collection.insertOne(document);
        mongoClient.close();
    }
}
