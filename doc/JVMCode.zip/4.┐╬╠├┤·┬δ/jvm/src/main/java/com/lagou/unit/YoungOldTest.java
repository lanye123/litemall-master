package com.lagou.unit;

/**
 * 1.设置年轻代和老年代的比例 1 : 4
 * 2.设置 伊甸园  from  to  8: 1: 1
 */
public class YoungOldTest {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("hello");
        Thread.sleep(3000000);
    }
}