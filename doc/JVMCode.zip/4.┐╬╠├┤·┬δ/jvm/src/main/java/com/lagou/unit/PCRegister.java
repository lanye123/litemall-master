package com.lagou.unit;

public class PCRegister {
    public static void main(String[] args) {
        int i = 1;
        int j = 2;
        int z = i + j;
        int y = 5;
        int s = z * y;
    }
}
