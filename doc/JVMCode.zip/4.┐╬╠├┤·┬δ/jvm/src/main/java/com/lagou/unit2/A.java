package com.lagou.unit2;

public class A {
         static int a ;
         public static void main(String[] args) {
             System.out.println(a);
        }
     }