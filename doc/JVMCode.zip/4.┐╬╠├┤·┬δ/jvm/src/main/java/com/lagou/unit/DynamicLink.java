package com.lagou.unit;

public class DynamicLink {

    public static void main(String[] args) {
         Math.random();
    }

}
