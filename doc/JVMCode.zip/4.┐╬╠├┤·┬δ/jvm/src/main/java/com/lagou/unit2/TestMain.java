package com.lagou.unit2;

public class TestMain
{
    private static int i;
    private double d;

    public static void print() {
    }

    private boolean trueOrFalse(){
        return false;
    }
}