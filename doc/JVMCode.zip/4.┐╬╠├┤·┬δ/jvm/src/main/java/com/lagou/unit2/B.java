package com.lagou.unit2;

public class B {
    public static void main(String[] args) {
        int a ;
        //System.out.println(a);
    }
}